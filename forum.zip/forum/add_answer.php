<?php
$host="localhost"; 
$username="root"; 
$password=""; 
$db_name="eachteach"; 
$tbl_name="fanswer";
 
$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$id=$_POST['id'];
 
$sql="SELECT MAX(a_id) AS Maxa_id FROM $tbl_name WHERE question_id='$id'";
$result=mysqli_query($con,$sql);
$rows=mysqli_fetch_array($result);
 
if ($rows) {
$Max_id = $rows['Maxa_id']+1;
}
else {
$Max_id = 1;
}
 
$a_name=$_POST['a_name'];
$a_answer=$_POST['a_answer'];
 
$datetime=date("d/m/y H:i:s");
 
$sql2="INSERT INTO $tbl_name(question_id, a_id, a_name, a_answer, a_datetime)VALUES('$id', '$Max_id', '$a_name', '$a_answer', '$datetime')";
$result2=mysqli_query($con,$sql2);
 
if($result2){
echo "Successful<BR>";
header("Location: view_topic.php?id=".$id);
 
$tbl_name2="fquestions";
$sql3="UPDATE $tbl_name2 SET reply='$Max_id' WHERE id='$id'";
$result3=mysqli_query($con,$sql3);
}
else {
echo "ERROR";
}
 
mysqli_close($con);
?>