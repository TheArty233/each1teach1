<?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fcategory";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$sql="SELECT * FROM $tbl_name ORDER BY id DESC";

$result=mysqli_query($con,$sql);
?>

<table width="90%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="6%" align="center" bgcolor="orange"><strong>#</strong></td>
<td width="53%" align="center" bgcolor="orange"><strong>Category</strong></td>
<td width="13%" align="center" bgcolor="orange"><strong>Date/Time</strong></td>
</tr>

<?php

while($rows = mysqli_fetch_array($result)){
?>
<tr>
<td bgcolor="#FFFFFF"><?php echo $rows['id']; ?></td>
<td bgcolor="#FFFFFF"><a href="main_forum.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['category']; ?></a><BR></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['datetime']; ?></td>
</tr>

<?php
}
mysqli_close($con);
?>

<tr>
<td colspan="5" align="right" bgcolor="orange"><a href="new_category.php"><strong>Create New Category</strong> </a></td>
</tr>
</table>
