<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Forums</title>

    <link href="bootstrap.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet" type="text/css" />
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../css/normalize.css" rel="stylesheet" type="text/css" />
    <link href="../css/animate.css" rel="stylesheet" type="text/css" />


  </head>
<body>
<?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fcategory";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$sql="SELECT * FROM $tbl_name ORDER BY id ASC";

$result=mysqli_query($con,$sql);
?>

<table width="30%" border="1" align="left" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC" >
<tr>
<td width="6%" align="center" bgcolor="orange"><strong>Categories</strong></td>
</tr>

<?php

while($rows = mysqli_fetch_array($result)){
?>
<tr>
<td bgcolor="#FFFFFF"><a href="main_forum.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['category']; ?></a><BR><?php echo $rows['detail']; ?></td>
</tr>

<?php
}
mysqli_close($con);
?>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
<!--trying to insert the first forum (ETO Functionality) on the right side of the page. Ideally every clicked category should open up on this ride side. The categories should be static on the left sidebar, visible no matter where a viewer within the Topics -->


<iframe class="main_forum" src="main_forum.php?id=0" style="position:fixed; top:0px; left:325px; bottom:0px; right:0px; width:100%; height:100%;"></iframe>

</body>

</html>
