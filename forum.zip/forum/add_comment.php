<?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fcomment";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$comment=$_POST['reply'];
$name=$_POST['name'];
$id=$_POST['id'];

$datetime=date("d/m/y h:i:s");

$sql="INSERT INTO $tbl_name(`postid`,`comment`,`name`, `datetime`)VALUES('$id' ,'$comment', '$name', '$datetime')";
$result=mysqli_query($con,$sql);

if($result){
header("Location: view_comment.php?id=".$id);
}
else {
echo "ERROR";
}
mysqli_close($con);
?>
