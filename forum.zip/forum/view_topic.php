<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>View Topic</title>

    <link href="bootstrap.css" rel="stylesheet">

  </head>
  <body>
<font = Indie Flower>

    <nav class ="navbar navbar-inverse"></nav>

    <div class = "container">
      </div>

      <?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fquestions";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$id=$_GET['id'];
$sql="SELECT * FROM $tbl_name WHERE id='$id'";
$result=mysqli_query($con,$sql);
$rows=mysqli_fetch_array($result);
?>

<H4><table width="400" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bordercolor="1" bgcolor="#FFFFFF">
<tr>

<td>  Topic :    <?php echo $rows['topic']; ?>  </td>
</tr>

<tr>
<td>  Details :  <?php echo $rows['detail']; ?></td>
</tr>

<tr>
<td>  By :   <?php echo $rows['name']; ?>   Email :   <?php echo $rows['email'];?></td>
</tr>

<tr>
<td>  Date/time :   <?php echo $rows['datetime']; ?></td>
</tr>
</table></td>
</tr>
</table>
<BR>
</H4>
<?php

$tbl_name2="fanswer";
$sql2="SELECT * FROM $tbl_name2 WHERE question_id='$id'";
$result2=mysqli_query($con,$sql2);
while($rows=mysqli_fetch_array($result2)){
?>
<style>th { text-align: left; background-color: orange;}</style>
<table width="50%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<th>  Name  </th>
<th>  Reply  </th>
<th>  Date/Time  </th>
</tr>
<tr>
<td><?php echo $rows['a_name']; ?></td>
<td><?php echo $rows['a_answer']; ?></td>
<td><?php echo $rows['a_datetime']; ?></td>
</tr>

<tr>
<td><a href="view_comment.php?id=<?php echo $rows['question_id']; ?>"><button type = "button" class "btn btn-warning">replies</button></a></td>
</tr>
</table></td>
</tr>
</table><br>
<?php
}

$sql3="SELECT view FROM $tbl_name WHERE id='$id'";
$result3=mysqli_query($con,$sql3);
$rows=mysqli_fetch_array($result3);
$view=$rows['view'];

if(empty($view)){
$view=1;
$sql4="INSERT INTO $tbl_name(view) VALUES('$view') WHERE id='$id'";
$result4=mysqli_query($con,$sql4);
}

$addview=$view+1;
$sql5="update $tbl_name set view='$addview' WHERE id='$id'";
$result5=mysqli_query($con,$sql5);
mysqli_close($con);
?>

<BR>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form name="form1" method="post" action="add_answer.php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<td width="18%">  Name  </td>
<td width="3%">:</td>
<td width="79%"><input name="a_name" type="text" id="a_name" size="45"></td>
</tr>
<tr>
<td valign="top">  Answer  </td>
<td valign="top">:</td>
<td><textarea name="a_answer" cols="45" rows="3" id="a_answer"></textarea></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input name="id" type="hidden" value="<?php echo $id; ?>"></td>
<td><input type="submit" class = "btn btn-warning" name="Submit" value="Submit"> <input type="reset" class = "btn btn-warning" name="Submit2" value="Reset"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>


</body>
</html>
