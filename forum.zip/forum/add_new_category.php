<?php
$host="localhost"; 
$username="root"; 
$password=""; 
$db_name="eachteach"; 
$tbl_name="fcategory"; 
 
$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");
 
$category=$_POST['category'];
$detail=$_POST['detail'];
$name=$_POST['name'];
$email=$_POST['email'];
 
$datetime=date("d/m/y h:i:s"); 
 
$sql="INSERT INTO $tbl_name(category, detail, name, email, datetime)VALUES('$category', '$detail', '$name', '$email', '$datetime')";
$result=mysqli_query($con,$sql);
 
if($result){
header("Location: category.php");
}
else {
echo "ERROR";
}
mysqli_close($con);
?>