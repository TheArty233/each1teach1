<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Forums</title>

    <link href="bootstrap.css" rel="stylesheet">

  </head>
  <body>
<font = Indie Flower>

    <nav class="navbar navbar-inverse"></nav>

    <div class="container">
        ETO contents
      </div>
    <?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fquestions";
$id  = $_GET['id'];

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$sql="SELECT * FROM $tbl_name where categoryid = '$id' ORDER BY id DESC";

$result=mysqli_query($con,$sql);
?>

<table width="100%" border = "0" align="right" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="6%" align="center" bgcolor="orange"><strong>#</strong></td>
<td width="53%" align="center" bgcolor="orange">Topic</td>
<td width="15%" align="center" bgcolor="orange">Views</td>
<td width="13%" align="center" bgcolor="orange"><strong>Replies</strong></td>
<td width="13%" align="center" bgcolor="orange"><strong>Date/Time</strong></td>
</tr>

<?php

while($rows = mysqli_fetch_array($result)){
?>
<tr>
<td bgcolor="#FFFFFF"><?php echo $rows['id']; ?></td>
<td bgcolor="#FFFFFF"><a href="view_topic.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['topic']; ?></a><BR></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['view']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['reply']; ?></td>
<td align="center" bgcolor="#FFFFFF"><?php echo $rows['datetime']; ?></td>
</tr>

<?php
}
mysqli_close($con);
?>

<tr>
<td colspan="5" align="right" bgcolor="orange"><a href="new_topic.php?id=<?php echo $_GET['id']; ?>"><button class="btn btn:hover" >Create New Topic</button> </a></td>
</tr>
</table>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>

</font>
  </body>
  </html>
