<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>View Topic</title>

    <link href="bootstrap.css" rel="stylesheet">

  </head>
  <body>
<font = Indie Flower>

    <nav class="navbar navbar-inverse"></nav>

    <div class="container">
      </div>

<?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fcomment";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$id=$_GET['id'];
$tbl_name2="fcomment";
$sql2="SELECT * FROM $tbl_name2 WHERE postid='$id'";
$result2=mysqli_query($con,$sql2);
while($rows=mysqli_fetch_array($result2)){
?>
<style>th { text-align: left; background-color: orange;}</style>
<table width="50%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<th> Name </th>
<th> Reply </th>
<th> Date/Time </th>
</tr>
<tr>
<td><?php echo $rows['name']; ?></td>
<td><?php echo $rows['comment']; ?></td>
<td><?php echo $rows['datetime']; ?></td>
</tr>
</table></td>
</tr>
</table><br>

<?php
}
$tbl_name3="reply";
$sql2="SELECT * FROM $tbl_name3 WHERE postid='$id'";
$result2=mysqli_query($con,$sql2);
while($rows=mysqli_fetch_array($result2)){
?>
<style>th { text-align: left; background-color: orange;}</style>
<table width="50%" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td><table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<th> Name </th>
<th> Reply </th>
<th> Date/Time </th>
</tr>
<tr>
<td><?php echo $rows['name']; ?></td>
<td><?php echo $rows['reply']; ?></td>
<td><?php echo $rows['datetime']; ?></td>
</tr>
</table></td>
</tr>
</table><br>

<?php
}
?>
<BR>
<table width="400" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form name="form1" method="post" action="add_comment.php">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
<tr>
<td width="18%"> Name </td>
<td width="3%">:</td>
<td width="79%"><input name="name" type="text" id="a_name" size="45"></td>
</tr>
<tr>
<td valign="top"> Reply </td>
<td valign="top">:</td>
<td><textarea name="reply" cols="45" rows="3" id="a_answer"></textarea></td>
</tr>
<tr>
<td>&nbsp;</td>
<td><input name="id" type="hidden" value="<?php echo $id; ?>"></td>
<td><input type="submit" class="btn btn-warning" name="Submit" value="Submit"> <input type="reset" class = "btn btn-warning" name="Submit2" value="Reset"></td>
</tr>
</table>
</td>
</form>
</tr>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>
</body>
</html>
