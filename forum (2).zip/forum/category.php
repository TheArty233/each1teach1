<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

    <title>Forums</title>

    <link href="bootstrap.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet" type="text/css" />
    <link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="../css/normalize.css" rel="stylesheet" type="text/css" />
    <link href="../css/animate.css" rel="stylesheet" type="text/css" />

  </head>

<body data-spy="scroll" data-target=".navbar" data-offset="50">

  <nav class="navbar navbar-default navbar-fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <a class="navbar-brand" href="#">
          <img alt="Each1Teach1" src="../media/img/ETO_FullLogo1.png" width = "65px">
        </a>
      </div>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input class="form-control" placeholder="Search" type="text">
        </div>
      <button type="submit" class="btn btn-default">Submit</button>
    </form>
    <ul class="nav navbar-nav navbar-right">
        <li><a href="profile.html"><img id='img' alt="Connect" src="../media/icn/avatar.png" width = "25px"> </a></li>
        <li class="active"><a href="#"><img alt="Home" src="../media/icn/home.png" class="thumb"></a></li>
        <li><a href="#"><img alt="Connect" src="../media/icn/Chats.png" class="thumb"></a></li>
        <li><a href="#"><img alt="Forums" src="../media/icn/forums.png" class="thumb"></a></li>
        <li><a href="#"></a></li>
        <li><a href="#"></a></li>


      </ul>
    </div>
  </nav>


<?php
$host="localhost";
$username="root";
$password="";
$db_name="eachteach";
$tbl_name="fcategory";

$con = mysqli_connect("$host", "$username" ,"$password" , "$db_name");

$sql="SELECT * FROM $tbl_name ORDER BY id ASC";

$result=mysqli_query($con,$sql);
?>

<table width="90%" border="0" align="center" cellpadding="3" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<td width="6%" align="center" bgcolor="orange"><strong>Categories</strong></td>
</tr>

<?php

while($rows = mysqli_fetch_array($result)){
?>
<tr>
<td bgcolor="#FFFFFF"><a href="main_forum.php?id=<?php echo $rows['id']; ?>"><?php echo $rows['category']; ?></a><BR><?php echo $rows['detail']; ?></td>
</tr>

<?php
}
mysqli_close($con);
?>
</table>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="bootstrap.min.js"></script>

</body>

</html>
